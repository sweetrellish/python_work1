menu = ('Apples', 'Oranges', 'Bananas', 'Pears', 'Kiwis')
#original tuple list
for food in menu:
    print(food)
#print original list

menu = ('Green Apples', 'Oranges', 'Bananas', 'Pears', 'Kiwis')
#change tuple list
for food in menu:
    print(food)
#print changed tuple list