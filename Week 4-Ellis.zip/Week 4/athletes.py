athletes = ['Michael Jordan', 'Lou Gherig', 'Kobe Bryant']
#list of athletes

for x in athletes:
    print(f'{x} is one of my favorite athletes.')
#for loop to print statement for each element
print("\nThese are my favorite athletes.")

