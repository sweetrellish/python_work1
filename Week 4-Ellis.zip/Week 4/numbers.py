numbers = list(range(1,21,2))
#list off odd numbers from 0-20

print("The following is a list of odd numbers between 0 and 20.")
for value in numbers:
    print(value)
#print statement and for loop printing numbers

print(f"The smallest value is {min(numbers)}")
#print statement showing smallest number
print(f"The highest number is {max(numbers)}")
#print statemtn showing highest number
print(f"The sum of the numbers is {sum(numbers)}")
#print statement showing sum of number list
