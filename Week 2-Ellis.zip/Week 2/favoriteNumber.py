prompt = "What is your favorite number?\n"
#initiliaze variable prompt

num = input(prompt) #input user number into num
num = int(num) #set num as integer

print("Your favorite nummber is", num)
#print statement including integer
