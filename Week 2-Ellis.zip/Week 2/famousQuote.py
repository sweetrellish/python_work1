print("Albert Einstein once said, \"A person who never made a mistake never tried anything new.\"")
#print statement of entire quote adding quotes using \ before declaration of quote marks