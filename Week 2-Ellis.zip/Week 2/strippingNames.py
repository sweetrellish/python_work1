name = "\tRyan Ellis\n"
#store name into variable name

print(name.lstrip()) #strip leading side whitespace
print(name.rstrip()) #strip trailing side whitespace
print(name.strip()) #strip all whitespace
