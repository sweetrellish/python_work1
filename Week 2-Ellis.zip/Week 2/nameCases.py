name = "ryan ellis"
#initialize variable name with a name

print(name.lower()) #prints all lower case
print(name.upper()) #prints all upper case
print(name.title()) #prints first letter in every instance as upper case
