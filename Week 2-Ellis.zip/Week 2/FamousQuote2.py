name = "Albert Einstein" 
quote = "\"A person who never made a mistake never tried anything new.\""
#initialize both variables to be 2 parts of quote
print(name, "once said,", quote)
#combine variables into print statement