name = "Ryan"
#initialize variable to store a name for the printed message

print("Hello ", name, ", would you like to learn Python?")
#print message with variable in message