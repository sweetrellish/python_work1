prompt = "Hello Python World!"
 #initialize variable prompt with first message
print(prompt)
#print variable prompt

prompt = "Goodbye!"
#change value of variable prompt
print(prompt)
#print variable prompt again 
