print("4 + 4 = ", 4 + 4) #print calculation of addition
print("11 - 3 = ", 11 - 3) #print calculation of subtraction
print("2 x 4 = ", 2 * 4) #print calculation of multiplication
print("16 / 2 = ", int(16 / 2)) #print calculation of division and convert from float to int