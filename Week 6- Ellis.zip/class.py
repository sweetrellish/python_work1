list = {'course_title': 'Intro to Programming', 'course_id': 'CMP-135-D01', 'number_students': '21', 'Instructor': 'Michael Kelley'}
#create list of course info

for value in list:
    print(value, ':' ,list[value])
#loop through values and print course info by key