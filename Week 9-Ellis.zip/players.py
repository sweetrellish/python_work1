def show_players(list):
    """Passes list to print values"""
    for player in list:
        print(player)
        #list argument prints list
    
players = ['Kobe Bryant', 'Shaq', 'Michael Jordan']
show_players(players)
#definition of list passing through function call