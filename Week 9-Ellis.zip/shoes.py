def purchase_shoes(style, brand):
    """Takes shoe info and prints values"""
    print(f"Your order of {brand} {style} shoe is being processed.")


purchase_shoes('Basketball', 'Nike')
purchase_shoes(style='Running', brand='Under Armour')