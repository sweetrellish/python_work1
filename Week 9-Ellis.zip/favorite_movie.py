def favorite_movie(title):
    """Display favorite movie"""
    print(f"My favorite movie is {title}")
#define function


favorite_movie('Star Wars')
#function call